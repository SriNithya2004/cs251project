#!/bin/bash

cd "$1"

awk '{ for (i=1;i<=NF;i++) words[$i]++ }
END { for (k in words) {

	if(words[k] >=1)
	c++

     }
     printf "%s\n",c
     
}' *.txt
