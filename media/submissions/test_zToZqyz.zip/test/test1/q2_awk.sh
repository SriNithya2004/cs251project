#!/bin/bash

i=1
c=2
words=0

while read line;
do
	sum=0
	p=1
	d=$(($i%3))
	f=$((c*d))
	k=$(($f+8))
	revline=$(echo $line|awk '{do printf "%s"(NF>1?FS:RS),$NF;while(--NF)}')
	for word in $revline;
	do
		if [[ $(printf "%d" "'${word}") -gt 57 || $(printf "%d" "'${word}") -lt 48 ]]
		then
			word=$(($(printf "%d" "'${word}")-87))
		fi	
		sum=$(($sum+$((p*word))))
		p=$((p*k))		
	done
	echo $sum
	i=$(($i+1))
done < $1
