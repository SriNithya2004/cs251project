sed -z 's/\.\n/:)\n/g;s/\./\$/g' $1
